import os
import re
import sqlite3
import threading
import time
from datetime import datetime, timezone

import requests
from flask import Flask, render_template, request

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deployment")

DB_PATH = os.environ.get("DB_PATH", "orders.db")
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
ADMIN_CHAT_ID = os.environ.get("ADMIN_CHAT_ID", "")
TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}"

# Edit these packages and prices to match your real, authorized offers.
BUNDLES = {
    "30go": {"name": "30 Go", "price": "3.50", "currency": "USD"},
    "10go": {"name": "10 Go", "price": "1.50", "currency": "USD"},
    "5go": {"name": "5 Go", "price": "0.90", "currency": "USD"},
}

PHONE_PATTERN = re.compile(r"^\+243\d{9}$")


def db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                phone TEXT NOT NULL,
                bundle_code TEXT NOT NULL,
                bundle_name TEXT NOT NULL,
                price TEXT NOT NULL,
                currency TEXT NOT NULL,
                decision TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL
            )
        """)


def telegram_request(method, payload=None, timeout=35):
    if not BOT_TOKEN:
        return None
    try:
        response = requests.post(
            f"{TELEGRAM_API}/{method}",
            json=payload or {},
            timeout=timeout
        )
        response.raise_for_status()
        return response.json()
    except requests.RequestException as exc:
        app.logger.warning("Telegram API request failed: %s", exc)
        return None


def send_admin_message(message):
    if not BOT_TOKEN or not ADMIN_CHAT_ID:
        app.logger.warning("Telegram is not configured; order was saved locally.")
        return
    telegram_request("sendMessage", {
        "chat_id": ADMIN_CHAT_ID,
        "text": message
    })


def set_order_decision(order_id, decision):
    with db_connection() as conn:
        cursor = conn.execute(
            "UPDATE orders SET decision = ? WHERE order_id = ?",
            (decision, order_id)
        )
        return cursor.rowcount > 0


def get_order(order_id):
    with db_connection() as conn:
        return conn.execute(
            "SELECT * FROM orders WHERE order_id = ?",
            (order_id,)
        ).fetchone()


def process_telegram_update(update):
    message = update.get("message") or update.get("edited_message")
    if not message:
        return

    chat_id = str(message.get("chat", {}).get("id", ""))
    text = (message.get("text") or "").strip()

    # Only the configured admin chat can use bot commands.
    if not ADMIN_CHAT_ID or chat_id != str(ADMIN_CHAT_ID):
        return

    if text.startswith("/start") or text.startswith("/help"):
        telegram_request("sendMessage", {
            "chat_id": ADMIN_CHAT_ID,
            "text": (
                "Website order bot is connected.\\n\\n"
                "Commands:\\n"
                "/approve ORDER_ID - approve an order\\n"
                "/reject ORDER_ID - reject an order"
            )
        })
        return

    parts = text.split()
    if len(parts) == 2 and parts[0] in ("/approve", "/reject"):
        order_id = parts[1].strip().upper()
        decision = "approved" if parts[0] == "/approve" else "rejected"
        order = get_order(order_id)

        if not order:
            reply = f"Order {order_id} was not found."
        elif order["decision"] != "pending":
            reply = f"Order {order_id} has already been reviewed."
        elif set_order_decision(order_id, decision):
            reply = f"{decision.title()}: {order_id}"
        else:
            reply = f"Could not update {order_id}. Please try again."

        telegram_request("sendMessage", {
            "chat_id": ADMIN_CHAT_ID,
            "text": reply
        })


def telegram_polling_loop():
    """Long-poll Telegram for admin commands. Run one Render instance only."""
    if not BOT_TOKEN or not ADMIN_CHAT_ID:
        app.logger.info("Telegram polling is off: BOT_TOKEN or ADMIN_CHAT_ID is missing.")
        return

    # Remove any old webhook because getUpdates and webhooks cannot run together.
    telegram_request("deleteWebhook", {"drop_pending_updates": False}, timeout=15)
    offset = None

    while True:
        try:
            params = {"timeout": 25}
            if offset is not None:
                params["offset"] = offset

            response = requests.get(
                f"{TELEGRAM_API}/getUpdates",
                params=params,
                timeout=35
            )
            response.raise_for_status()
            data = response.json()

            if data.get("ok"):
                for update in data.get("result", []):
                    offset = update["update_id"] + 1
                    process_telegram_update(update)
        except Exception as exc:
            app.logger.warning("Telegram polling issue: %s", exc)
            time.sleep(5)


@app.get("/")
def home():
    return render_template("index.html", bundles=BUNDLES)


@app.post("/order")
def create_order():
    phone = request.form.get("phone", "").strip().replace(" ", "")
    bundle_code = request.form.get("bundle", "").strip()

    if not PHONE_PATTERN.fullmatch(phone):
        return render_template(
            "index.html",
            bundles=BUNDLES,
            error="Enter a valid DR Congo number in +243XXXXXXXXX format."
        ), 400

    bundle = BUNDLES.get(bundle_code)
    if not bundle:
        return render_template(
            "index.html",
            bundles=BUNDLES,
            error="Please select a valid data package."
        ), 400

    # This is a demonstration order only. No real payment is collected here.
    order_id = "ORD-" + datetime.now(timezone.utc).strftime("%y%m%d%H%M%S") + str(int(time.time() * 1000) % 1000)
    created_at = datetime.now(timezone.utc).isoformat()

    with db_connection() as conn:
        conn.execute("""
            INSERT INTO orders
            (order_id, phone, bundle_code, bundle_name, price, currency, decision, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)
        """, (
            order_id, phone, bundle_code, bundle["name"],
            bundle["price"], bundle["currency"], created_at
        ))

    admin_message = (
        "NEW DEMO WEBSITE ORDER\\n"
        f"Order: {order_id}\\n"
        f"Phone: {phone}\\n"
        f"Bundle: {bundle['name']}\\n"
        f"Price: {bundle['price']} {bundle['currency']}\\n\\n"
        "Review the order and use one command:\\n"
        f"/approve {order_id}\\n"
        f"/reject {order_id}\\n\\n"
        "Demo only: payment has not been collected or verified."
    )
    send_admin_message(admin_message)

    return render_template("received.html", order_id=order_id)


@app.get("/health")
def health():
    return {"ok": True}


init_db()

# Start one polling worker per app process. On Render, use ONE instance.
if BOT_TOKEN and ADMIN_CHAT_ID:
    polling_thread = threading.Thread(target=telegram_polling_loop, daemon=True)
    polling_thread.start()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "10000")))
