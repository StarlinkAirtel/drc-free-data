# Render website demo

## Files
- `app.py`: Flask application and Telegram admin bot
- `templates/index.html`: order form
- `templates/received.html`: simple confirmation page
- `requirements.txt`: Python dependencies

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:10000

## Deploy on Render
1. Upload this folder to a GitHub repository.
2. In Render choose **New > Web Service** and connect the repository.
3. Runtime: Python.
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app`
6. Add environment variables:
   - `BOT_TOKEN` = token from BotFather
   - `ADMIN_CHAT_ID` = your Telegram numeric chat ID
   - `SECRET_KEY` = a long random secret
7. Deploy.

Use one Render instance because this demo uses Telegram long polling.
For persistent orders on Render, attach a persistent disk and set `DB_PATH`
to a file path on that disk, such as `/var/data/orders.db`.

## Telegram commands
Send `/start` to the bot from the configured admin account.
Use `/approve ORD-...` or `/reject ORD-...`.

## Important
This is a demonstration order flow. It does not process Airtel Money payments,
activate data bundles, or verify payments. Do not collect customers' payment PINs
or OTPs. Connect a legitimate payment provider and authorized data-activation
service before accepting real orders.
